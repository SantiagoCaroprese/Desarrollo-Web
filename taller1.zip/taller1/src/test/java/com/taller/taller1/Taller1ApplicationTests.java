package com.taller.taller1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Taller1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
